package com.ugb.controlesbasicos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private int calcularFactorial(double num) {
        if (num == 0 || num == 1) {
            return 1;
        } else {
            int factorial = 1;
            for (int i = 2; i <= num; i++) {
                factorial *= i;
            }
            return factorial;
        }
    }

    TextView tempVal;
    Button btn;
    RadioGroup opt;
    Spinner spn;
    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btn = findViewById(R.id.btnCalcular);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tempVal = findViewById(R.id.txtnum1);
                String num1Str = tempVal.getText().toString();
                double num1 = 0;
                if (!num1Str.isEmpty()) {
                    num1 = Double.parseDouble(num1Str);
                }

                tempVal = findViewById(R.id.txtnum2);
                String num2Str = tempVal.getText().toString();
                double num2 = 0;
                if (!num2Str.isEmpty()) {
                    num2 = Double.parseDouble(num2Str);
                }

                double respuesta = 0;
                opt = findViewById(R.id.optOpciones);
                spn = findViewById(R.id.spnOpciones);
                switch (opt.getCheckedRadioButtonId()) {
                    case R.id.optSuma:
                        respuesta = num1 + num2;
                        break;
                    case R.id.optResta:
                        respuesta = num1 - num2;
                        break;
                    case R.id.optMulplicacion:
                        respuesta = num1 * num2;
                        break;
                    case R.id.optDivision:
                        if (num2 != 0) {
                            respuesta = num1 / num2;
                        } else {

                            Toast.makeText(MainActivity.this, "Error: División por cero", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        break;
                    case R.id.optPorcentaje:
                        respuesta = (num1 / 100) * num2;
                        break;
                    case R.id.optExponente:
                        respuesta =  Math.pow(num1, num2);
                        break;
                    case R.id.optFactorial:
                        respuesta =  calcularFactorial(num1);
                        break;
                    case R.id.optRaiz:
                        respuesta =  Math.sqrt(num1);
                        break;

                }
                switch (spn.getSelectedItemPosition()) {
                    case 0:
                        break;
                    case 1:
                        respuesta = num1 + num2;
                        break;
                    case 2:
                        respuesta = num1 - num2;
                        break;
                    case 3:
                        respuesta = num1 * num2;
                        break;
                    case 4:
                        if (num2 != 0) {
                            respuesta = num1 / num2;
                        } else {

                            Toast.makeText(MainActivity.this, "Error: División por cero", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        break;
                    case 5:
                        respuesta = (num1 / 100) * num2;
                        break;
                    case 6:
                        respuesta = Math.pow(num1, num2);
                        break;
                    case 7:
                        respuesta = calcularFactorial(num1);
                        break;
                    case 8:
                        respuesta = Math.sqrt(num1);

                        break;
                }

                tempVal = findViewById(R.id.lblrespuesta);
                tempVal.setText("Respuesta: " + respuesta);
            }
        });
    }
}